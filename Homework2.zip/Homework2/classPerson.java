
public class Person {
private String name;
private static int  birthyear;
private static String input;
private static String output;
private static int age;
private static int nowadays = 2017;

public Person(){
	}

public Person(String name){
	this.name = name;
}

public String getName() {
	return name;
	}

	public void setName(String name) {
	this.name = name;
	}

	public int getBirthyear(){
		return birthyear;
	}
	
	public void setBirthyear(int Birthyear){
		this.birthyear = birthyear;
	}
	
	public void changeName(String name) {
		this.name = name;
		}
	
	
	
	public static  int getAge(){
		return (int) (nowadays- Person.birthyear);
	}
	
	public String toOutput(){
		return "Person [ name=" + name + ", age=" + age +"] ";
	}
	
}
